function mode = nc_fill_mode()
% NC_FILL_MODE:  returns integer mnemonic for NC_FILL
%
% USAGE:  mode = nc_fill_mode;
mode = 0;
return


